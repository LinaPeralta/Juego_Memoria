
class Progreso{


constructor (images,x1,y1){
    this.x1=x1;
    this.y1=y1;
    this.img0=images;
    this.img1=images;
    this.img2=images;
    this.img3=images;
    this.img4=images;
    this.img5=images;
    this.img6=images;
    this.img7=images;
    this.img8=images;
}

pintarCero (){
   // image1(this.image1, this.x1, this.y1);
   img0=loadImage('data/cero.png') ;
}
pintarUno (){
    img1=loadImage('data/uno.png') ;
 }
 pintarDos (){
    img2=loadImage('data/dos.png') ;
 }
 pintarTres (){
    img3=loadImage('data/tres.png') ;
 }
 pintarCuatro (){
    img4=loadImage('data/cuatro.png') ;
 }
 pintarCinco (){
    img5=loadImage('data/cinco.png') ;
 }
 pintarSeis (){
    img6=loadImage('data/seis.png') ;
 }
 pintarSiete (){
    img7=loadImage('data/siete.png') ;
 }
 pintarOcho (){
    img6=loadImage('data/ocho.png') ;
 }
}
