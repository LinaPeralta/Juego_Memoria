class Cartas{

constructor (x,y,images,type) {
    this.x=x;
    this.y=y;
    this.img=images[type];
    this.type=type;
    this.completo = false;
    this.mostrar = false;
}

pintar (){
  if (!this.completo){
    if (!this.mostrar) {
        fill(255);
        rect(this.x, this.y, 45, 45,10);
      } else {
        image(this.img, this.x, this.y);
      }
    } else {
      image(this.img, this.x, this.y);
    }
}

validar (x1,y1){
  let resultado = false;
 if (x1 > this.x && x1 < this.x + 50 && y1 > this.y + 50 && !this.mostrar && !this.completo){
   return true;
 }
 return resultado;
}

setCompleto(completo){
  this.completo = completo;
}
setMostrar(mostrar){
  this.mostrar = mostrar;
}
getType(){
  return this.type;
}
getCompleto(){
  return this.completo;
}
getMostrar(){
  return this.mostrar;
}

}