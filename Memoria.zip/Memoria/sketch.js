let carta1;               
let carta2;
let cartas = [];          
let images = [];  
let puntaje;     
let contador;               
let click=0;
let img,img1;

let barra= 32;

function preload() {
  let indicator = 0;    
  for (let index = 0; index < 8; index++) {
      images[index] = loadImage('/data/fruta' + indicator + '.png');    
      indicator++;    
  } 

  img= loadImage('data/enunciado.png');
img1= loadImage('data/reset.png');
}

function restart () {
  let type = [0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7];
  shuffle(type,true);

  let indice = 0;
  let x = 70;
  let y = 150; 
  
  contador = 0;
  puntaje = 0;

  for (let i = 0; i < 16; i++) {        
      let tipoCarta = type[i];
      let imagenCarta = images[tipoCarta];
      cartas[i]= new Carta (x, y, imagenCarta, tipoCarta);
      x+=60;
      if(x>=300){
        x=70;
        y+=60;
      }
      indice++;
  }
}

function setup() {
  createCanvas(330,550); 
  carta1 = null;
  carta2 = null;
  restart();
}


function draw() {
  background(246,231,231); 
  
  
  if (click == 1){


  fill(246,231,231);
  rect(165+70, 60, 40, 40);
  image(img1,165+70,60);


  cartas.forEach((carta) => {    
    carta.pintar();
  });

  validarCartas();

  fill(255);
  rectMode(CENTER);
   rect(width/2, 450,240,20,10);
   fill(0);
   text(puntaje + "/8", width/2, 535);

   fill(186,29,29);
   rectMode(CENTER);
  rect(width/2, 450,barra*puntaje,20,10);
   

  }

   if (click == 0) {
     
    image(img,0,20);
   
      noStroke();
      fill(255);
      rect(120,400,90,30,10);
      textSize(18);
     fill(94, 12, 12);
     text('Jugar', 140, 420);
   
  
   } 

 
}

function mousePressed() {
  for (let i = 0; i < cartas.length; i++) {
   cartas[i].validar(mouseX, mouseY);
   if(cartas[i].validar(mouseX, mouseY)) {
     if(carta1 == null) {
       carta1 = cartas[i];
       cartas[i].setMostrar(true);
     } else if (cartas[i] !== carta1 && carta2 == null) {
       carta2 = cartas[i];
       cartas[i].setMostrar(true);
     }
   }
  }

  
  if (dist(mouseX,mouseY,170,400)){
    click=1;
  }

  
  if(mouseX > width/2-165 && mouseX < width/2+110 && mouseY > 60 && mouseY < 100){
    restart();
  }
  

  
}
function validarCartas() {
  if(carta1 !== null && carta2 !== null) {
        if (carta1.getTipo() == carta2.getTipo()){
          carta1.setMostrar(true);
          carta2.setMostrar(true);
          carta1 = null;
          carta2 = null;
          puntaje ++;
        } else {
          contador++;
          if(contador > 80){
            carta1.setMostrar(false);
            carta2.setMostrar(false);
            carta1 = null;
            carta2 = null;
            contador = 0;
          }
        }
  }
}

