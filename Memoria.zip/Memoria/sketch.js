let images=[];
let cartas=[];
let activado = true;
let cartaA = null;
let cartaB = null;
let barra=[];
let click=0;
let presionar;

//imagenes
let img,img1;
let jugar;
let cero,uno,dos,tres,cuatro,cinco,seis,siete,ocho;

function preload(){

img= loadImage('data/enunciado.png');
img1= loadImage('data/reset.png');


  let ind = 0;
  for (let index=0; index<8;index++){
    image [index]=loadImage('data/fruta'+ind+'.png') ;
    ind++;
}
}

function reset(){
 // randomeOne = 0;

  let type = [0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7];
  shuffle (type,true);
  let x=35;
  let y=100;

  for (let index = 0; index < 16; index++) {
    cartas[index]=new Cartas(x,y,image,type[index]);
   // cartas[index]=new Cartas(10+x,10+y,image,type[index]);
    x+=60;

    if (x>=245){
      y+=70;
      x=35;
    } 
 }
}

function setup() {
  createCanvas(330,550);
  reset();
}

function draw() {
  background(246,231,231);

  if (click == 0) {
     
   image(img,0,20);
   //image(img1,120,400);
    //boton jugar
     noStroke();
     fill(255);
     rect(120,400,90,30,10);
     textSize(18);
    fill(94, 12, 12);
    text('Jugar', 140, 420);
  

  } 
if (click == 1){

  //cartas.forEach((cartas)=>{
   // cartas.display();
 // })
  //reset button 
  image(img1,235,20);

    //barra de progreso
   // barra=new Progreso(images,x1,y1);
   fill(255);
   rect(20,490,290,20,10);
 
   //acondiciones para la aparicion de la barra de progreso
  //poner ifs, del contador de las parejas que ha encontrado

  for (let index = 0; index < cartas.length; index++) {
    cartas[index].pintar();
  }
  validarCartaSeleccionada();
}
}

function validarCartaSeleccionada(){
  if (cartaA !== null && cartaB !== null){
    if (cartaA.getType() === cartaB.getType()){
    cartaSeleccionadaCompleto();
    } else {
    resetearCartasSeleccionadas();
    }
  }
}

function cartaSeleccionadaCompleto(){
activado =  false;
setTimeout(() => {
cartaA.setMostrar(true);
cartaB.setMostrar(true);
cartaA.setCompleto(true);
cartaB.setCompleto(true);
cartaA= null;
cartaB = null;
activado = true;
},400);
}

function resetearCartasSeleccionadas  (){
  activado = false;
  setTimeout(() => {
    cartaA.setMostrar(false);
    cartaB.setMostrar(false);
    cartaA.setCompleto(false);
    cartaB.setCompleto(false);
    scartaA= null;
    cartaB = null;
    activado = true;
    },400);

}

 function mousePressed (){
  //pasar de pantalla 0 a 1
   if (dist(mouseX,mouseY,170,400)){
     click=1;
   }
   //boton reset

   if (dist(mouseX,mouseY,40,450)){
     reset();
   }
 
   if (activado){
    cartas.forEach((cartas)=> {
      if (cartas.validar(mouseX,mouseY)){
        if (cartaA == null){
          cartaA = cartas;
          cartas.setMostrar(true);
          return true;
        } else if (cartaB === null && cartas !== cartaA){
          cartaB = cartas;
          cartas .setMostrar(true);
          return true;
        }
      }
    })
   }


 }
   


 