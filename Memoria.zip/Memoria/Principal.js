let x,y,ancho,altura;

function setup() {
    createCanvas(375, 667);

}

function draw() {
    background(225);
    
    //reset button 
    // rect(30,200,);





}
